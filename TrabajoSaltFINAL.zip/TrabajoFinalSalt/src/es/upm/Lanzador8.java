package es.upm;

/**
 * @author Alberto S�nchez 
 *         Antonio San Agust�n 
 *         Alberto Campos
 */
public class Lanzador8 extends Funcion{
	public Lanzador8 () {

			super(29.25, 1.98, Math.toRadians(4.8), Math.toRadians(34.19));// Valores de vLanzamiento, alturaLanzador, 
			                                                      //dispersionAngular, angulo, expresadas en unidades del sistema internacional
	}
	
}