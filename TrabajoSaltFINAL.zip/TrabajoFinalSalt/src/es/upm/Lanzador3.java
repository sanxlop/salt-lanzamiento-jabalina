package es.upm;

/**
 * @author Alberto S�nchez 
 *         Antonio San Agust�n 
 *         Alberto Campos
 */
public class Lanzador3 extends Funcion{
	public Lanzador3 () {

			super(29.68, 1.88, Math.toRadians(4.4), Math.toRadians(34.15));// Valores de vLanzamiento, alturaLanzador, 
			                                                    //dispersionAngular, angulo, expresadas en unidades del sistema internacional
	}
	
}
