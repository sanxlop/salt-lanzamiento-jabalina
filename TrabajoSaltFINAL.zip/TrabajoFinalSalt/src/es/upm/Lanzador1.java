package es.upm;

/**
 * @author Alberto S�nchez 
 *         Antonio San Agust�n 
 *         Alberto Campos
 */
public class Lanzador1 extends Funcion{
	public Lanzador1 () {

			super(29.65, 1.91, Math.toRadians(4.1), Math.toRadians(34.32));// Valores de vLanzamiento, alturaLanzador,
			                                                      //dispersionAngular, angulo, expresadas en unidades del sistema internacional
	}
	
}