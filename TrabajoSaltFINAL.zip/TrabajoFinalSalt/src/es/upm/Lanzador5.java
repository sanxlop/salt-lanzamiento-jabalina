package es.upm;

/**
 * @author Alberto S�nchez 
 *         Antonio San Agust�n 
 *         Alberto Campos
 */
public class Lanzador5 extends Funcion{
	public Lanzador5 () {

			super(29.32, 1.90, Math.toRadians(4.5), Math.toRadians(33.91));// Valores de vLanzamiento, alturaLanzador, 
			                                                      //dispersionAngular, angulo, expresadas en unidades del sistema internacional
	}
	
}