package es.upm;

/**
 * @author Alberto S�nchez 
 *         Antonio San Agust�n 
 *         Alberto Campos
 */
public class Lanzador2 extends Funcion{
	public Lanzador2 () {

			super(29.53, 1.99, Math.toRadians(4.3), Math.toRadians(35.25));// Valores de vLanzamiento, alturaLanzador, 
			                                                      //dispersionAngular, angulo, expresadas en unidades del sistema internacional
	}
	
}