package es.upm;

/**
 * @author Alberto S�nchez 
 *         Antonio San Agust�n 
 *         Alberto Campos
 */
public class Lanzador7 extends Funcion{
	public Lanzador7 () {

			super(29.27, 1.88, Math.toRadians(4.8), Math.toRadians(34.11));// Valores de vLanzamiento, alturaLanzador, 
			                                                      //dispersionAngular, angulo, expresadas en unidades del sistema internacional
	}
	
}