package es.upm;

/**
 * @author Alberto S�nchez 
 *         Antonio San Agust�n 
 *         Alberto Campos
 */
public class Lanzador4 extends Funcion{
	public Lanzador4 () {

			super(29.20, 1.82, Math.toRadians(5), Math.toRadians(33.81));// Valores de vLanzamiento, alturaLanzador, 
			                                                      //dispersionAngular, angulo, expresadas en unidades del sistema internacional
	}
	
}